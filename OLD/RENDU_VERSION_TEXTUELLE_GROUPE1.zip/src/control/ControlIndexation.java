package control;

public class ControlIndexation {
	
	public boolean lancerIndexation() {
		//Inserer ici l'interfa�age C
		return true;
	}
}
