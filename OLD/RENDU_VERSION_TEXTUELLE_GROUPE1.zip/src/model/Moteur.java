package model;

public class Moteur {
	private int nbOccTxt;
	private int  nbEch ;
	private int nbIntervallle;
	private int nbBitsCouleur;
	public Moteur(int nbOccTxt,int  nbEch,int nbIntervallle,int nbBitsCouleur){
		this.nbOccTxt=nbOccTxt;
		this.nbEch=nbEch;
		this.nbIntervallle=nbIntervallle;
		this.nbBitsCouleur=nbBitsCouleur;
	}
}
