Informations relatives au r�pertoire SRC:

1) Pour tester l'application textuelle lancer le BoundaryNaviguer qui se situe dans src/vuetextuelle

2) -un compte administrateur est inscrit dans le fichier des profils: identifiant = admin.admin, mot de passe=admin
   -sinon cr�ez un compte utilisateur

3) Pour cette premi�re version nous n'avons pas fait de try/catch pour �viter toutes les erreurs qui pourraient crasher au runtime
   car c'est une version temporaire.

4) Les comptes cr��s sont persistants, ainsi vous pourrez fermer l'application puis la relancer et vous connecter avec les memes identifiants.

5) De la m�me mani�re les historiques de recherche le sont aussi.