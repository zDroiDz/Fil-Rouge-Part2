#ifndef by_keyword_h
#define by_keyword_h

void byword (char motClef[]) ;
void appelerDesId(int id);


#endif
