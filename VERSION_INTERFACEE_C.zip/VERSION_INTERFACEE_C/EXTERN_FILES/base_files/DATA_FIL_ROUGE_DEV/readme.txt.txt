# Projet FIL ROUGE : DONNEES de DEVELOPPEMENT
# 4/12/2017 

L'archive contient : 

les fichiers images RGB et images NB, des fichiers audio, et des fichiers xml pour les documents textes. 
Si vous avez des soucis d'encodage (affichage des accents), il est possible de convertir les fichiers textes en utilisant la commande iconv. Cela d�pend de votre environnement. 

  #Utilisation de la commande ICONV
  # iconv -f format_initial -t format_final fichier_a_traiter > fichier_resultant
  # iconv -l donne la liste des formats possibles

  # Conna�tre l'encodage d'un fichier avec la commande FILE
  # file nom_fichier permet de conna�tre l'encodage d'un fichier

