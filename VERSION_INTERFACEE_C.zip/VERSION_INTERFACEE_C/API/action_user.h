#ifndef action_user
#define action_user

int modeUser();


#endif
