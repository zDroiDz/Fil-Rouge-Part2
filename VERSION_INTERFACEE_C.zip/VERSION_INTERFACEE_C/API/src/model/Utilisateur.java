package model;

public class Utilisateur  extends Profil{

	public Utilisateur(String prenom, String nom, String mdp) {
		super(prenom, nom, mdp);
		
	}

	

}
