package model;

public enum ProfilUtilisateur {
 ADMIN, UTILISATEUR, ADMING;
}
