#ifndef action_admin
#define action_admin
#include "menu.h"
int modeAdmin();

#endif
