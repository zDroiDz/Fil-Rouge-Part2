package control;

public class ControlChangerModeRecherche {

	public ControlChangerModeRecherche(){
		
	}
	
	public boolean connexion(){
		boolean connexionOK = false;
		return connexionOK;
	}
	
	public boolean setMode(){
		boolean changement = false;
		return changement;
	}
}
