package model;

public class DescripteurSon extends Descripteur {
	
	private int tab[][];
	
	
	public DescripteurSon() {
		// TODO Auto-generated constructor stub
		
	}
	
	public void addContent()
	{
		
	}

}