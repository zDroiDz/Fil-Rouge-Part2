package model;

public enum ProfilUtilisateur {
ADMING, ADMIN, UTILISATEUR;
}
