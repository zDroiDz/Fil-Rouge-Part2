package model;

import java.util.HashMap;
import java.util.Map;

public class DescripteurImage extends Descripteur {
	
	private int tabR[][];
	private int tabG[][];
	private int tabB[][];
	
	
	public DescripteurImage() {
		// TODO Auto-generated constructor stub
	}
	
	public void addContent()
	{
		
	}

}