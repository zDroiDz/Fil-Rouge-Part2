package model;

public class Utilisateur  extends Profil{

	public Utilisateur(String nom, String prenom, String mdp) {
		super(nom, prenom, mdp);
		
	}

	

}
