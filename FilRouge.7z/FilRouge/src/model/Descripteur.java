package model;

public abstract class Descripteur {
	
	private String path;
	private int id;
	private String nomFichier;

}